import styles from "./Footer.module.css";

export default function Footer() {
  return (
    <div>
      <p className={styles.title}>made with love @ kranji</p>
    </div>
  );
}
